import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import networkx as nx


# Cargar los datos
gastos = pd.read_csv('data/Gastos.csv')
recursos_humanos = pd.read_csv('data/RecursosHumanos.csv')
nodos_organizacion = pd.read_csv('data/NodosOrganizacion.csv')

# Filtros interactivos en la barra lateral
year = st.sidebar.selectbox('Seleccionar Año', ['Todos'] + list(gastos['Año'].unique()))
jurisdiccion = st.sidebar.selectbox('Seleccionar Jurisdicción', ['Todas'] + list(gastos['JURISDICCIÓN'].unique()))
subjurisdiccion = st.sidebar.selectbox('Seleccionar Subjurisdicción', ['Todas'] + list(gastos['SUBJURISDICCIÓN'].unique()))

# Función para filtrar los datos
def filtrar_datos(df, columna, valor):
    return df if valor == 'Todas' or valor == 'Todos' else df[df[columna] == valor]

# Aplicar filtros
gastos_filtrados = gastos.copy()
recursos_humanos_filtrados = recursos_humanos.copy()

gastos_filtrados = filtrar_datos(gastos_filtrados, 'Año', year)
gastos_filtrados = filtrar_datos(gastos_filtrados, 'JURISDICCIÓN', jurisdiccion)
gastos_filtrados = filtrar_datos(gastos_filtrados, 'SUBJURISDICCIÓN', subjurisdiccion)

recursos_humanos_filtrados = filtrar_datos(recursos_humanos_filtrados, 'Año', year)
recursos_humanos_filtrados = filtrar_datos(recursos_humanos_filtrados, 'JURISDICCIÓN', jurisdiccion)

# Crear gráficos de Gastos
st.title("Análisis del Presupuesto por Año")

# Agrupar los datos por Año y Objeto Detalle
gastos_agrupados = gastos_filtrados.groupby(['Año', 'Objeto Detalle'])['Monto'].sum().reset_index()

# Calcular el total por año para los porcentajes
gastos_total_por_anio = gastos_agrupados.groupby('Año')['Monto'].sum().reset_index()
gastos_total_por_anio = gastos_total_por_anio.rename(columns={'Monto': 'Total'})

# Unir con el total por año y calcular el porcentaje
gastos_agrupados = gastos_agrupados.merge(gastos_total_por_anio, on='Año')
gastos_agrupados['Porcentaje'] = gastos_agrupados['Monto'] / gastos_agrupados['Total'] * 100

# Ordenar los datos para que los valores más altos estén en la parte inferior
gastos_agrupados = gastos_agrupados.sort_values(['Año', 'Monto'])

# Crear subplots con más espacio entre gráficos
fig_gastos = make_subplots(rows=1, cols=2, subplot_titles=("Gastos Totales", "Gastos Porcentuales"),
                           specs=[[{"type": "bar"}, {"type": "bar"}]], horizontal_spacing=0.15)

# Crear barras para cada objeto detalle
for objeto in gastos_agrupados['Objeto Detalle'].unique():
    objeto_data = gastos_agrupados[gastos_agrupados['Objeto Detalle'] == objeto]
    
    # Gráfico de barras apiladas (nominal)
    fig_gastos.add_trace(
        go.Bar(x=objeto_data['Año'], y=objeto_data['Monto'], name=objeto,
               hoverinfo='text', text=objeto_data['Monto'].apply(lambda x: f'{x:,.0f}')),
        row=1, col=1
    )
    
    # Gráfico de barras apiladas (porcentual)
    fig_gastos.add_trace(
        go.Bar(x=objeto_data['Año'], y=objeto_data['Porcentaje'], name=objeto,
               hoverinfo='text', text=objeto_data['Porcentaje'].apply(lambda x: f'{x:.2f}%')),
        row=1, col=2
    )

# Actualizar diseño
fig_gastos.update_layout(barmode='stack', title_text="Gastos por Objeto Detalle y Año", height=600, width=1400)
fig_gastos.update_xaxes(title_text="Año", row=1, col=1)
fig_gastos.update_xaxes(title_text="Año", row=1, col=2)
fig_gastos.update_yaxes(title_text="Monto Total", row=1, col=1)
fig_gastos.update_yaxes(title_text="Porcentaje", row=1, col=2)

st.plotly_chart(fig_gastos)

# Crear gráficos de Recursos Humanos
recursos_humanos_agrupados = recursos_humanos_filtrados.groupby(['Año', 'JURISDICCIÓN'])['Cantidad Cargos'].sum().reset_index()

# Calcular el total por año para los porcentajes
rrhh_total_por_anio = recursos_humanos_agrupados.groupby('Año')['Cantidad Cargos'].sum().reset_index()
rrhh_total_por_anio = rrhh_total_por_anio.rename(columns={'Cantidad Cargos': 'Total'})

# Unir con el total por año y calcular el porcentaje
recursos_humanos_agrupados = recursos_humanos_agrupados.merge(rrhh_total_por_anio, on='Año')
recursos_humanos_agrupados['Porcentaje'] = recursos_humanos_agrupados['Cantidad Cargos'] / recursos_humanos_agrupados['Total'] * 100

# Ordenar los datos para que los valores más altos estén en la parte inferior
recursos_humanos_agrupados = recursos_humanos_agrupados.sort_values(['Año', 'Cantidad Cargos'])

# Crear subplots con más espacio entre gráficos
fig_rrhh = make_subplots(rows=1, cols=2, subplot_titles=("Cantidad de Cargos", "Porcentaje de Cargos"),
                         specs=[[{"type": "bar"}, {"type": "bar"}]], horizontal_spacing=0.15)

# Crear barras para cada jurisdicción
for jurisdiccion in recursos_humanos_agrupados['JURISDICCIÓN'].unique():
    jurisdiccion_data = recursos_humanos_agrupados[recursos_humanos_agrupados['JURISDICCIÓN'] == jurisdiccion]
    
    # Gráfico de barras apiladas (nominal)
    fig_rrhh.add_trace(
        go.Bar(x=jurisdiccion_data['Año'], y=jurisdiccion_data['Cantidad Cargos'], name=jurisdiccion,
               hoverinfo='text', text=jurisdiccion_data['Cantidad Cargos'].apply(lambda x: f'{x:,.0f}')),
        row=1, col=1
    )
    
    # Gráfico de barras apiladas (porcentual)
    fig_rrhh.add_trace(
        go.Bar(x=jurisdiccion_data['Año'], y=jurisdiccion_data['Porcentaje'], name=jurisdiccion,
               hoverinfo='text', text=jurisdiccion_data['Porcentaje'].apply(lambda x: f'{x:.2f}%')),
        row=1, col=2
    )

# Actualizar diseño
fig_rrhh.update_layout(barmode='stack', title_text="Recursos Humanos por Jurisdicción y Año", height=600, width=1400)
fig_rrhh.update_xaxes(title_text="Año", row=1, col=1)
fig_rrhh.update_xaxes(title_text="Año", row=1, col=2)
fig_rrhh.update_yaxes(title_text="Cantidad de Cargos", row=1, col=1)
fig_rrhh.update_yaxes(title_text="Porcentaje", row=1, col=2)

st.plotly_chart(fig_rrhh)

# Crear gráfico jerárquico (organigrama) desde NodosOrganizacion
st.write(nodos_organizacion.head())
st.title("Organigrama")

# Crear gráfico jerárquico (organigrama) desde NodosOrganizacion
fig_organigrama = go.Figure(go.Treemap(
    labels=nodos_organizacion['unidad'],  # Nombre del área como etiqueta
    parents=nodos_organizacion['reporta_a'],  # 'reporta_a' como padres
    ids=nodos_organizacion['Cod_Nodo'],  # Identificador único para cada nodo
    values=nodos_organizacion['Gastos'],  # Gastos para determinar el tamaño
    text=nodos_organizacion['RecursosHumanos'],  # Recursos humanos como texto adicional
    hovertemplate='<b>%{label}</b><br>Gastos: %{value}<br>RRHH: %{text}<br>Código: %{id}<extra></extra>'
))

fig_organigrama.update_layout(
    title="Jerarquía Organizacional",
    height=300,
    width=600
)

st.plotly_chart(fig_organigrama)



st.title("Organigrama con Networkx")

# Asumiendo que ya has cargado tus datos en un DataFrame llamado 'nodos_organizacion'
# Si no es así, primero carga tus datos:
# nodos_organizacion = pd.read_csv('tu_archivo.csv')

# Mostrar los primeros registros del DataFrame
st.write("Primeros registros de la tabla:")
st.write(nodos_organizacion.head())

# Mostrar información sobre los tipos de datos
st.write("Tipos de datos de las columnas:")
st.write(nodos_organizacion.dtypes)

# Mostrar información sobre valores nulos
st.write("Conteo de valores nulos por columna:")
st.write(nodos_organizacion.isnull().sum())

# Verificar y corregir nombres de columnas
column_mapping = {
    'Cod_Nodo': 'Cod_Nodo',
    'unidad': 'unidad',
    'reporta_a': 'reporta_a',
    'Gastos': 'Gastos',
    'RecursosHumanos': 'RecursosHumanos'
}

for expected, actual in column_mapping.items():
    if expected not in nodos_organizacion.columns:
        st.warning(f"Columna esperada '{expected}' no encontrada. Usando '{actual}' en su lugar.")
    else:
        column_mapping[expected] = expected

# Crear un grafo dirigido
G = nx.DiGraph()

# Agregar nodos y conexiones
for _, row in nodos_organizacion.iterrows():
    G.add_node(row[column_mapping['Cod_Nodo']], 
               name=row[column_mapping['unidad']], 
               gastos=row[column_mapping['Gastos']], 
               rrhh=row[column_mapping['RecursosHumanos']])
    if pd.notna(row[column_mapping['reporta_a']]) and row[column_mapping['reporta_a']] != '':
        G.add_edge(row[column_mapping['reporta_a']], row[column_mapping['Cod_Nodo']])

# Identificar nodos raíz
root_nodes = [node for node, in_degree in G.in_degree() if in_degree == 0]

# Si hay múltiples nodos raíz, crear un nodo raíz artificial
if len(root_nodes) > 1:
    artificial_root = 'ROOT'
    G.add_node(artificial_root, name='Organización', gastos=0, rrhh=0)
    for root in root_nodes:
        G.add_edge(artificial_root, root)
    root_nodes = [artificial_root]

# Usar un layout jerárquico
pos = nx.spring_layout(G, k=0.5, iterations=50)

# Crear trazas para nodos y conexiones
edge_x = []
edge_y = []
for edge in G.edges():
    x0, y0 = pos[edge[0]]
    x1, y1 = pos[edge[1]]
    edge_x.extend([x0, x1, None])
    edge_y.extend([y0, y1, None])

edge_trace = go.Scatter(
    x=edge_x, y=edge_y,
    line=dict(width=0.5, color='#888'),
    hoverinfo='none',
    mode='lines')

node_x = []
node_y = []
for node in G.nodes():
    x, y = pos[node]
    node_x.append(x)
    node_y.append(y)

node_trace = go.Scatter(
    x=node_x, y=node_y,
    mode='markers+text',
    hoverinfo='text',
    marker=dict(
        showscale=True,
        colorscale='YlGnBu',
        reversescale=True,
        color=[],
        size=10,
        colorbar=dict(
            thickness=15,
            title='Gastos',
            xanchor='left',
            titleside='right'
        ),
        line_width=2))

# Agregar color y texto a los nodos
node_adjacencies = []
node_text = []
for node, adjacencies in enumerate(G.adjacency()):
    node_adjacencies.append(len(adjacencies[1]))
    node_info = G.nodes[adjacencies[0]]
    node_text.append(f"{node_info.get('name', 'N/A')}<br>Gastos: {node_info.get('gastos', 'N/A')}<br>RRHH: {node_info.get('rrhh', 'N/A')}")

node_trace.marker.color = node_adjacencies
node_trace.text = node_text

# Crear la figura
fig = go.Figure(data=[edge_trace, node_trace],
             layout=go.Layout(
                title='Organigrama',
                titlefont_size=16,
                showlegend=False,
                hovermode='closest',
                margin=dict(b=20,l=5,r=5,t=40),
                annotations=[ dict(
                    text="",
                    showarrow=False,
                    xref="paper", yref="paper",
                    x=0.005, y=-0.002 ) ],
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
                )

# Mostrar el gráfico
st.plotly_chart(fig)

# Información adicional para depuración
st.write("Nodos raíz:", root_nodes)
st.write("Total de nodos:", G.number_of_nodes())
st.write("Total de conexiones:", G.number_of_edges())
